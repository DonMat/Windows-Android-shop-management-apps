package com.mo.MgRsklep.MySQL;


public interface PasswordListener {
    void getPass(String[] password);
}
