package com.mo.MgRsklep.EncryptionMethods;

public interface Encryption {
    String encrypt(String input);
}
