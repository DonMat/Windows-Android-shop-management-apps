package com.mo.MgRsklep.MySQL;


public interface UserInfoListener {
    void getUserInfo(String[] info);
}
