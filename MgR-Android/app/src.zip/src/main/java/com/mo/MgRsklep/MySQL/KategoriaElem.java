package com.mo.MgRsklep.MySQL;

public class KategoriaElem
{
	public String nazwa;
	public int id;
	public KategoriaElem(String nazwa, int id) {
		super();
		this.nazwa = nazwa;
		this.id = id;
	}	
}