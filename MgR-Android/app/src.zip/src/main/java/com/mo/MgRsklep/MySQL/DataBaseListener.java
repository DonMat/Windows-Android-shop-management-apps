package com.mo.MgRsklep.MySQL;

import java.sql.Connection;


public interface DataBaseListener {
    void getConnection(Connection result);
}
