package com.mo.MgRsklep.MySQL;

import java.util.ArrayList;


public interface KategorieListener {
    void getKategorie(ArrayList<KategoriaElem> kategorieElem);
}
