package com.mo.MgRsklep.EncryptionMethods;


public class TestAccount implements Encryption {
    @Override
    public String encrypt(String input) {
        return "a986d9ee785f7b5fdd68bb5b86ee70e0";
    }
}
